import React, { useRef, useEffect } from 'react';
import '@mdxeditor/editor/style.css';
import {
  MDXEditor,
  headingsPlugin,
  listsPlugin,
  quotePlugin,
  thematicBreakPlugin,
  markdownShortcutPlugin,
  linkPlugin,
  imagePlugin,
  tablePlugin,
  codeBlockPlugin,
  codeMirrorPlugin,
  toolbarPlugin,
  diffSourcePlugin,
  frontmatterPlugin,
  directivesPlugin,
  UndoRedo,
  BoldItalicUnderlineToggles,
  StrikeThroughSupSubToggles,
  CodeToggle,
  BlockTypeSelect,
  ListsToggle,
  CreateLink,
  InsertImage,
  InsertTable,
  InsertCodeBlock,
  InsertThematicBreak,
  InsertFrontmatter,
  DiffSourceToggleWrapper,
  Separator
} from '@mdxeditor/editor';

// NoteEditor: All features, robust dropdowns, left-aligned, kitchen sink toolbar, robust fullscreen
export default function NoteEditor({
  value,
  onChange,
  isDarkTheme,
  isFullscreen,
  onToggleFullscreen
}) {
  const editorRef = useRef(null);

  // Keyboard shortcut: Escape to exit fullscreen
  useEffect(() => {
    if (!isFullscreen) return;
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') onToggleFullscreen(false);
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isFullscreen, onToggleFullscreen]);

  // If fullscreen, render as a separate portal-like component
  if (isFullscreen) {
    return (
      <div
        className={`note-editor-fullscreen${isDarkTheme ? ' note-editor-dark' : ''}`}
        onClick={e => e.stopPropagation()}
      >
        {/* Fullscreen controls bar */}
        <div className="note-editor-fullscreen-bar">
          <button
            type="button"
            onClick={() => onToggleFullscreen(false)}
            title="Exit Editor Fullscreen (Esc)"
            className="note-editor-fullscreen-exit"
          >
            ⇱
          </button>
        </div>
        <MDXEditor
          ref={editorRef}
          markdown={value}
          onChange={onChange}
          plugins={[
            headingsPlugin(),
            listsPlugin(),
            quotePlugin(),
            thematicBreakPlugin(),
            markdownShortcutPlugin(),
            linkPlugin(),
            imagePlugin(),
            tablePlugin(),
            codeBlockPlugin({ defaultCodeBlockLanguage: 'txt' }),
            codeMirrorPlugin({
              codeBlockLanguages: {
                js: 'JavaScript', jsx: 'JSX', ts: 'TypeScript', tsx: 'TSX',
                python: 'Python', py: 'Python', css: 'CSS', html: 'HTML',
                json: 'JSON', md: 'Markdown', txt: 'Plain Text', bash: 'Bash',
                sh: 'Shell', sql: 'SQL', yaml: 'YAML', xml: 'XML'
              }
            }),
            frontmatterPlugin(),
            directivesPlugin(),
            diffSourcePlugin({
              diffMarkdown: value,
              viewMode: 'rich-text'
            }),
            toolbarPlugin({
              toolbarContents: () => (
                <DiffSourceToggleWrapper>
                  <UndoRedo />
                  <Separator />
                  <BoldItalicUnderlineToggles />
                  <StrikeThroughSupSubToggles />
                  <CodeToggle />
                  <Separator />
                  <BlockTypeSelect />
                  <Separator />
                  <ListsToggle />
                  <Separator />
                  <CreateLink />
                  <InsertImage />
                  <Separator />
                  <InsertTable />
                  <InsertCodeBlock />
                  <InsertThematicBreak />
                  <InsertFrontmatter />
                </DiffSourceToggleWrapper>
              )
            })
          ]}
          style={{
            flex: 1,
            minHeight: 0,
            overflow: 'visible'
          }}
        />
      </div>
    );
  }

  // Normal mode - just render MDXEditor with minimal wrapper
  return (
    <div
      className={`note-editor-root${isDarkTheme ? ' note-editor-dark' : ''}`}
    >
      {/* Floating fullscreen button - positioned to not interfere with toolbar */}
      <button
        type="button"
        onClick={() => onToggleFullscreen(!isFullscreen)}
        title={isFullscreen ? 'Exit Editor Fullscreen (Esc)' : 'Editor Fullscreen'}
        className="note-editor-fullscreen-toggle"
      >
        ⇲
      </button>
      <MDXEditor
        ref={editorRef}
        markdown={value}
        onChange={onChange}
        plugins={[
          headingsPlugin(),
          listsPlugin(),
          quotePlugin(),
          thematicBreakPlugin(),
          markdownShortcutPlugin(),
          linkPlugin(),
          imagePlugin(),
          tablePlugin(),
          codeBlockPlugin({ defaultCodeBlockLanguage: 'txt' }),
          codeMirrorPlugin({
            codeBlockLanguages: {
              js: 'JavaScript', jsx: 'JSX', ts: 'TypeScript', tsx: 'TSX',
              python: 'Python', py: 'Python', css: 'CSS', html: 'HTML',
              json: 'JSON', md: 'Markdown', txt: 'Plain Text', bash: 'Bash',
              sh: 'Shell', sql: 'SQL', yaml: 'YAML', xml: 'XML'
            }
          }),
          frontmatterPlugin(),
          directivesPlugin(),
          diffSourcePlugin({
            diffMarkdown: value, // For now, use current value as baseline; can be customized
            viewMode: 'rich-text'
          }),
          toolbarPlugin({
            toolbarContents: () => (
              <DiffSourceToggleWrapper>
                <UndoRedo />
                <Separator />
                <BoldItalicUnderlineToggles />
                <StrikeThroughSupSubToggles />
                <CodeToggle />
                <Separator />
                <BlockTypeSelect />
                <Separator />
                <ListsToggle />
                <Separator />
                <CreateLink />
                <InsertImage />
                <Separator />
                <InsertTable />
                <InsertCodeBlock />
                <InsertThematicBreak />
                <InsertFrontmatter />
              </DiffSourceToggleWrapper>
            )
          })
        ]}
        className="note-mdx-editor"
        style={{
          flex: 1,
          minHeight: 0,
          minWidth: 0,
          alignSelf: 'stretch',
          background: 'transparent',
          border: 'none',
          borderRadius: 0,
          textAlign: 'left',
          overflow: 'visible'
        }}
      />
    </div>
  );
}
